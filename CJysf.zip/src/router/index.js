import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)


const router = new VueRouter({
    routes: [

        {
            name: 'index',
            path: '/',
            redirect: '/index', //重定向
        },
        {
            path: '/index',
            name: "inidex",
            component: resolve => require(['@/views'], resolve),
            meta: {
                title: '来抽奖',
                keepAlive: false,
            }
        },
        {
            path: '/register',
            name: "register",
            component: resolve => require(['@/views/register'], resolve),
            meta: {
                title: '注册',
                keepAlive: false,
            }
        }
    ]
})

export default router