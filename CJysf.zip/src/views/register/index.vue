<template>
  <div class="Box wrap">
    <div class="title">
      <p class="pc p1">送百万豪礼</p>
      <p class="pc p2">百分百中奖</p>
      <p class="pcx p3">下载鹿途APP，完成指定任务</p>
      <p class="pcx p4">获得7天抽奖资格，每天可抽7次</p>
      <div class="bannerBox">
        <div class="banner">最低可获得现金 1 元，神秘大奖等着你</div>
      </div>
    </div>
    <div class="main">
      <!-- <div class="title"> -->
      <div class="huodong">
        <p class="title-huodong">活动说明</p>
        <div class="text-box">
          <p>1.填写参与用户信息</p>
          <p class="p-middle">2.下载鹿途APP，完成指定任务，即可参与啦</p>
          <p>3.百分百中奖，最低可中1元钱</p>
        </div>
      </div>
      <div class="from-box flex middle center">
        <div class="phone-btn"></div>
        <div v-if="false" class="from">
          <div class="from-title flex middle center">
            <img src="../../assets/img/left.png" alt />
            <span class="from-text">参与用户信息</span>
            <img src="../../assets/img/right.png" alt />
          </div>
          <div class="input-box flex middle center">
            <div class="from-input" style="flex:1;">
              <van-field v-model="phone" placeholder="请输入手机号" error-message />
              <!-- <input class="new-input" placeholder="请输入手机号" type="text" /> -->
            </div>
          </div>

          <div class="input-box flex middle center">
            <div class="from-input" style="flex:1;">
              <van-field v-model="phone" placeholder="请输入手机号" error-message />
              <!-- <input class="new-input" placeholder="请输入手机号" type="text" /> -->
            </div>
            <div class="code-btn">获取验证码</div>
          </div>

          <div class="input-box flex middel center">
            <div
              class="from-input flex middle center"
              style="background:#ffa63d!important;color:#fff;border-radius:10px;"
            >立即参与</div>
          </div>
        </div>
        <div class="activity-no">
          <img src="../../assets/img/noactivity.png" alt />
          <p>很遗憾，来晚了，活动已结束了</p>
        </div>
      </div>
      <!-- </div> -->
    </div>

    <!-- 弹窗 -->
    <div class="message" v-if="false">
      <div class="message-dialog">
        <div class="message-content">
          <div class="message-header">
            <img src="../../assets/img/titleicon.png" alt />
          </div>
          <div class="message-body">
            <div class="message-body-content">
              <p class="message-title">参与成功</p>
              <p class="message-xq">下载鹿途app注册登录即可抽奖啦，注册需与提交用户信息一致哦！</p>
            </div>
          </div>
          <div class="message-footer flex middle center">
            <div class="message-bg-box message-bg">立即下载</div>
          </div>
        </div>
        <img @click.prevent="closeBtn" class="close" src="../../assets/img/close.png" alt />
      </div>
    </div>
    <!-- 弹窗2 -->
    <div class="message" v-if="false">
      <div class="message-dialog">
        <div class="message-content">
          <div class="message-header">
            <img src="../../assets/img/liwu.png" alt />
          </div>
          <div class="message-body">
            <div class="message-body-content">
              <p class="message-title">该手机号已参与啦</p>
              <p class="message-xq">下载鹿途app注册登录即可抽奖啦，注册需与提交用户信息一致哦！</p>
            </div>
          </div>
          <div class="message-footer flex middle center">
            <div class="message-bg-box message-new flex-1">重新输入用户信息</div>
            <div class="message-bg-box message-new-xz">立即下载</div>
          </div>
        </div>
        <img @click.prevent="closeBtn" class="close" src="../../assets/img/close.png" alt />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    closeBtn() {
      event.stopPropagation();
      console.log("关掉了");
    }
  }
};
</script>

<style scoped lang="less" type="text/less">
.Box {
  width: 100%;
  height: 100%;
  background-image: url("../../assets/img/registerbg.png");
  background-position: center;
  background-size: 100% 100%;
  background-repeat: no-repeat;
  .title {
    margin-top: 30px;
    .pc {
      background: linear-gradient(180deg, #ffffff, #ffc280);
      -webkit-background-clip: text;
      color: transparent;
      font-weight: bold;
      letter-spacing: 5px;
    }
    .p1 {
      font-size: 120px;
    }
    .p2 {
      font-size: 80px;
      // margin-top: 10px;
      margin-bottom: 30px;
    }
    .pcx {
      font-size: 42px;
      font-family: HYYakuHei, HYYakuHei-75W;
      font-weight: bold;
      color: #ffcf9b;
      text-shadow: 0px 9px 8px 0px rgba(240, 51, 40, 0.5);
      letter-spacing: 5px;
    }
    .p3 {
      margin-bottom: 5px;
    }
    .p4 {
      margin-bottom: 40px;
    }
    .bannerBox {
      padding: 0 60px;
      .banner {
        height: 117px;
        line-height: 100px;
        text-align: center;
        background-image: url("../../assets/img/banner.png");
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
        font-size: 26px;
        font-family: FZLanTingHei-B-GBK, FZLanTingHei-B-GBK-Regular;
        font-weight: bold;
        color: #ffea97;
        letter-spacing: 2px;
      }
    }
  }
  .main {
    // background-color:#fff1b6 ;
    .huodong {
      margin-top: 120px;
      .title-huodong {
        font-size: 40px;
        font-family: Source Han Sans CN, Source Han Sans CN-Bold;
        font-weight: bold;
        text-align: center;
        color: #e74435;
      }
      .text-box {
        padding-left: 111px;
        padding-top: 20px;
        p {
          font-size: 26px;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: bold;
          text-align: left;
          color: #e74435;
          line-height: 39px;
        }
        .p-middle {
          margin-top: 10px;
          margin-bottom: 10px;
        }
      }
    }
    .from-box {
      margin-top: 60px;
      position: relative;
      .phone-btn {
        position: absolute;
        top: -120px;
        right: 0;
        width: 110px;
        height: 110px;
        background-image: url("../../assets/img/btnphone.png");
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
      }
      .activity-no {
        img {
          width: 346px;
          height: 286px;
        }
        p {
          margin-top: 35px;
          font-size: 26px;
          font-family: Source Han Sans CN, Source Han Sans CN-Bold;
          font-weight: 700;
          text-align: center;
          color: #e74435;
        }
      }
      .from {
        width: 750px;
        height: 546px;
        background-image: url("../../assets/img/frombg.png");
        background-position: center;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        .from-title {
          margin-top: 70px;
          img {
            width: 32px;
            height: 32px;
          }
          .from-text {
            margin-left: 20px;
            margin-right: 20px;
            font-size: 35px;
            font-family: PingFang SC, PingFang SC-Bold;
            font-weight: bold;
            color: #333333;
          }
        }
        .input-box {
          margin-top: 30px;
          padding: 0 80px !important;
          .from-input {
            width: 580px;
            height: 76px;
            background: #f0f4ff !important;
            font-size: 26px;
            .van-cell {
              background: #f0f4ff !important;
              // height:38px;
              line-height: 60px;
              font-size: 26px !important;
            }
          }
          .code-btn {
            width: 200px;
            height: 76px;
            line-height: 76px;
            text-align: center;
            background: #ffa63d;
            border-radius: 10px;
            color: #ffffff;
            margin-left: 10px;
            font-size: 26px;
          }
          .new-input {
            padding-left: 20px;
            width: 100%;
            height: 76px;
            border-radius: 10px;
          }
        }
      }
    }
  }

  // 弹窗
  // 弹窗
  .message {
    position: fixed;
    z-index: 999;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    display: table;
    visibility: visible;
    background-color: rgba(0, 0, 0, 0.6);
    .message-dialog {
      width: 622px;
      height: 495px;
      background: #ffffff;
      border-radius: 20px;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      .close {
        position: absolute;
        left: 50%;
        bottom: -120px;
        transform: translateX(-50%);
        z-index: -1;
        height: 200px;
      }
      .message-content {
        max-width: 540px;
        margin: 0px auto;
        background-color: #fff;
        border-radius: 20px;
        box-sizing: border-box;
        .message-header {
          img {
            margin-top: -112px;
            width: 320px;
            height: 224px;
          }
        }
        .message-body {
          position: relative;
          max-height: 300px;
          overflow: auto !important;
          .message-body-content {
            .message-title {
              text-align: center;
              font-size: 32px;
              font-family: PingFang SC, PingFang SC-Bold;
              font-weight: bold;
              text-align: center;
              color: #333333;
              margin-bottom: 32px;
              margin-top: 35px;
            }
            .message-xq {
              margin-bottom: 70px;
              font-size: 24px;
              font-family: PingFang SC, PingFang SC-Regular;
              text-align: center;
              color: #333333;
            }
          }
        }
        .message-footer {
          margin-bottom: 46px;
          .message-bg-box {
            height: 76px;
            line-height: 76px;
            background-image: url("../../assets/img/btn.png");
            background-position: center;
            background-size: 100% 100%;
            background-repeat: no-repeat;
            color: #fff;
            font-size: 28px;
            font-family: PingFang SC, PingFang SC-Bold;
            font-weight: bold;
            text-align: center;
          }
          .message-bg {
            width: 542px;
          }
          .message-new {
            width: 311px;
          }
          .message-new-xz {
            width: 200px;
            margin-left: 20px;
          }
        }
      }
    }
  }
}
</style>
