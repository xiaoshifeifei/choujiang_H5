module.exports = {
  authUrl: process.env.VUE_APP_AUTH_URL + '/mobile/wechat/auth',
  appid: process.env.WECHAT_APPID,
  // eslint-disable-next-line camelcase
  token_type: 'Bearer'
}
